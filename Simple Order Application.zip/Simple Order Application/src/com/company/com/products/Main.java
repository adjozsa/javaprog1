package com.company.com.products;

import com.company.com.products.orders.OrderItem;

public class Main {

    public static void main(String[] args) {
Product product = new Product(1,1);
Product product1 = new OrderItem("",1.d,1d);
    }
}
