package com.company.com.products;

public class Food extends Product
{
    public Food(double membersName, double membersPrice)
    {
        super(membersName, membersPrice);
    }
}
