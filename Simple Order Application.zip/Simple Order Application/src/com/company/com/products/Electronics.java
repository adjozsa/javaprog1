package com.company.com.products;

public class Electronics extends Product
{
    public Electronics(double membersName, double membersPrice)
    {
        super(membersName, membersPrice);
        Product electronics = new Electronics(membersName, membersPrice);
        electronics.toString();
    }


    private void assertEquals(String book, String simpleName)
    {
    }
}
