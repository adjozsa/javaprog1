package com.company.com.products;

public class Book extends Product
{
    public String getAuthorMember()
    {
        return authorMember;
    }

    public void setAuthorMember(String authorMember)
    {
        this.authorMember = authorMember;
        authorMember = ("noAuthor");
    }

    String authorMember;

    Book(double membersName, double membersPrice, String authorMember)
    {
        super(membersName, membersPrice);
    }

    @Override
    public String toString()
    {
        System.out.println(String.format(membersName + membersPrice + authorMember));
        assertEquals("Book", Book.class.getSimpleName());
        return String.format(membersName + membersPrice + authorMember);
    }

    private void assertEquals(String book, String simpleName)
    {
    }

}


