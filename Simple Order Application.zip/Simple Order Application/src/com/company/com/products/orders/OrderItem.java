package com.company.com.products.orders;

public class OrderItem
{
    String name;
    double price;
    double quantity;
    double discount;
    double ammount;

    OrderItem(String name, double price, double quantity)
    {name = this.name;
    price = this.price;
    quantity = this.quantity;


    }
    public void recalculateAmount(){
        double amount = (quantity * price) - discount;
    }
    @Override
    public String toString(){
        return  String.format(name,price,quantity);}
}
