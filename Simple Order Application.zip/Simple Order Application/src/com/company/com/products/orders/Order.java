package com.company.com.products.orders;

import java.util.ArrayList;

public class Order
{
    ArrayList<OrderItem>orders;
}
