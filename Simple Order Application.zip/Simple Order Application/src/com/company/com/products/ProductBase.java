package com.company.com.products;

abstract class ProductBase
{
    double membersName;

    public double getMembersName()
    {
        return membersName;
    }

    public void setMembersName(double membersName)
    {
        this.membersName = membersName;
    }

    public double getMembersPrice()
    {
        return membersPrice;
    }

    public void setMembersPrice(double membersPrice)
    {
        this.membersPrice = membersPrice;
    }

    double membersPrice;

    ProductBase(double membersName, double membersPrice){

        if (membersName<0){
            throw new IllegalArgumentException ("MembersName should not be a negaive number");
        }

    }   @Override
public String toString(){
    System.out.println(String.format( "You never should see this! :)"));
    return  String.format( "You never should see this! :)");}
}

